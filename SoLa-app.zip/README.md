# SoLa - Guj To Eng Learning App

SoLa is a static web app that can be installed from a supported browser after it is hosted on HTTPS. Keep these files together when downloading or publishing:

- `index.html`
- `Untitled-2.html`
- `firebase-config.js`
- `vocabulary-data.js`
- `manifest.webmanifest`
- `service-worker.js`
- `icon.svg`

## Test locally

Open a terminal in this folder and run:

```powershell
py -m http.server 8000
```

Then open `http://localhost:8000`. Service workers and installation are not available when opening the HTML directly using `file://`.

## Publish with GitHub Pages

1. Create a **public** GitHub repository for the app.
2. Upload the listed files to the repository's top level and commit them to the `main` branch.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. After GitHub Pages finishes deploying, share the URL it displays. The `index.html` file opens the app; visitors can choose **Install SoLa app** or their browser's **Install app / Add to Home screen** menu.

The developer contact email entered in the app will be publicly visible. Review it before publishing.

## Enable user accounts before public launch

The Firebase settings in `firebase-config.js` must come from your Firebase project's Web App configuration. Enable Email/Password and Phone sign-in in Firebase Authentication, then add the GitHub Pages hostname under Firebase Authentication's authorized domains. Phone sign-in requires HTTPS, internet access, and reCAPTCHA. Do not put private service-account credentials in this client-side app.

The service worker caches the app shell and static learning data for repeat visits. Account sign-in and speech recognition still require internet access.
