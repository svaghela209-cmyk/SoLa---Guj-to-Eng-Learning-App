// Paste the Firebase web app config from Firebase Console here.
// Never put private service-account credentials in this client-side file.
window.BOLCHAL_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  appId: ""
};
