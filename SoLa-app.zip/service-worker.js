"use strict";

const CACHE_NAME = "sola-shell-v1";
const APP_FILES = [
  "./",
  "./index.html",
  "./Untitled-2.html",
  "./firebase-config.js",
  "./vocabulary-data.js",
  "./manifest.webmanifest",
  "./icon.svg"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((key) => key.startsWith("sola-shell-") && key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

function fetchAndCache(request) {
  return fetch(request).then((response) => {
    if (!response.ok && response.type !== "opaque") return response;
    return caches.open(CACHE_NAME)
      .then((cache) => cache.put(request, response.clone()).then(() => response))
      .catch((error) => {
        console.error("SoLa could not update a cached file:", error);
        return response;
      });
  });
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;

  const url = new URL(request.url);
  if (url.origin === self.location.origin) {
    const isAppFile = APP_FILES.some((file) => new URL(file, self.location.href).pathname === url.pathname);
    if (!isAppFile) return;

    event.respondWith(
      fetchAndCache(request)
        .catch(async () => {
          const cached = await caches.match(request);
          if (cached) return cached;
          if (request.mode === "navigate") {
            const appPage = await caches.match("./Untitled-2.html");
            if (appPage) return appPage;
          }
          return Response.error();
        })
    );
    return;
  }

  if (url.hostname === "www.gstatic.com" && url.pathname.startsWith("/firebasejs/10.14.1/")) {
    event.respondWith(
      fetchAndCache(request)
        .catch(async () => (await caches.match(request)) || Response.error())
    );
  }
});
